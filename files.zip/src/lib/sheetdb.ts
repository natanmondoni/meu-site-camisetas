export async function enviarParaSheetDB(dados: any) {
  const resposta = await fetch("https://sheetdb.io/api/v1/sua_chave_aqui", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados),
  });
  return resposta;
}