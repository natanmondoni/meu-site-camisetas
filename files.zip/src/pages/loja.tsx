import ProductCard from "../components/ProductCard";
import { useState } from "react";

export default function Loja() {
  const [carrinho, setCarrinho] = useState([]);

  const produtos = [
    { id: 1, nome: "Camiseta Preta", preco: 99.0, imagem: "/camiseta-preta.jpg" },
    { id: 2, nome: "Camiseta Branca", preco: 99.0, imagem: "/camiseta-branca.jpg" },
  ];

  const adicionarAoCarrinho = (produto: any) => setCarrinho([...carrinho, produto]);

  return (
    <div className="min-h-screen bg-gray-claro">
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6">Camisetas Básicas</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {produtos.map((produto) => (
            <ProductCard
              key={produto.id}
              produto={produto}
              adicionarAoCarrinho={adicionarAoCarrinho}
            />
          ))}
        </div>
      </div>
    </div>
  );
}