type ProductProps = {
  produto: { id: number; nome: string; preco: number; imagem: string };
  adicionarAoCarrinho: (produto: any) => void;
};

export default function ProductCard({ produto, adicionarAoCarrinho }: ProductProps) {
  return (
    <div className="bg-white p-4 rounded-md shadow-md">
      <img src={produto.imagem} alt={produto.nome} className="w-full h-48 object-cover rounded-md" />
      <h2 className="text-xl font-bold mt-4">{produto.nome}</h2>
      <p className="text-gray-escuro mt-2">R$ {produto.preco.toFixed(2)}</p>
      <button
        onClick={() => adicionarAoCarrinho(produto)}
        className="mt-4 bg-gray-escuro text-white px-4 py-2 rounded-md"
      >
        Adicionar ao carrinho
      </button>
    </div>
  );
}