import { useState } from "react";
import { enviarParaSheetDB } from "../lib/sheetdb";

export default function FilaEspera() {
  const [formulario, setFormulario] = useState({ nome: "", email: "", instagram: "" });
  const [sucesso, setSucesso] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const resposta = await enviarParaSheetDB(formulario);
    if (resposta.status === 200) setSucesso(true);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-claro">
      <h1 className="text-2xl font-bold mb-4">Fila de Espera</h1>
      {!sucesso ? (
        <form
          onSubmit={handleSubmit}
          className="bg-white p-6 rounded-md shadow-md space-y-4"
        >
          <div>
            <label className="block text-gray-escuro">Nome:</label>
            <input
              type="text"
              required
              className="border border-gray-escuro p-2 rounded-md w-full"
              value={formulario.nome}
              onChange={(e) => setFormulario({ ...formulario, nome: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-gray-escuro">E-mail:</label>
            <input
              type="email"
              required
              className="border border-gray-escuro p-2 rounded-md w-full"
              value={formulario.email}
              onChange={(e) => setFormulario({ ...formulario, email: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-gray-escuro">Instagram (opcional):</label>
            <input
              type="text"
              className="border border-gray-escuro p-2 rounded-md w-full"
              value={formulario.instagram}
              onChange={(e) => setFormulario({ ...formulario, instagram: e.target.value })}
            />
          </div>
          <button
            type="submit"
            className="bg-gray-escuro text-white font-bold px-6 py-2 rounded-md"
          >
            Enviar
          </button>
        </form>
      ) : (
        <p className="text-green-500 font-bold">Inscrição realizada com sucesso!</p>
      )}
    </div>
  );
}