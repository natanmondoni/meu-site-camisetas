import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-claro">
      <h1 className="text-3xl font-bold text-gray-escuro">Nova coleção chegando</h1>
      <div className="mt-4">
        <img
          src="/mockup-camiseta.jpg"
          alt="Mockup de camiseta"
          className="w-64 h-64 object-cover opacity-50"
        />
      </div>
      <div className="mt-6 flex space-x-4">
        <Link href="/fila-espera">
          <a className="px-6 py-2 bg-gray-escuro text-white font-bold rounded-md">
            Entrar na fila de espera
          </a>
        </Link>
        <Link href="/loja">
          <a className="px-6 py-2 bg-gray-escuro text-white font-bold rounded-md">
            Ver camisetas básicas
          </a>
        </Link>
      </div>
    </div>
  );
}